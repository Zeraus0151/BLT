<?php 
  
if(isset($_COOKIE["user"])){ 
    echo "Auction Item is a  " . $_COOKIE["user"]; 
} else{ 
    echo "No items for auction."; 
} 
  
?> 