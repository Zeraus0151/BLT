<?php
class Tienda extends Controller{

    //private $texto;

    public function __construct() {
        parent::__construct();
        //$this->texto = "Olá Mundo!!";        
    }

    public function index(){
		$this->model = new ImagenDAO();
        $data['listJssor'] = $this->model->getJssor();
		
		$this->model = new JuegoDAO();
        $data['listJuego'] = $this->model->getListJuego();
		//echo var_dump($data['listJssor']);die;
		//$data['listImgs'] = $this->model->getListImagenes();
        $this->view->load('nav');
        $this->view->load('tienda',$data);
    }
	public function viewGame(){/*
		$this->model = new ImagenDAO();
        $data['listJssor'] = $this->model->getJssor();
		
		$this->model = new JuegoDAO();
        $data['listJuego'] = $this->model->getListJuego();
		//echo var_dump($data['listJssor']);die;
		//$data['listImgs'] = $this->model->getListImagenes();
        $this->view->load('nav');
        $this->view->load('tienda',$data);*/
    }
}
