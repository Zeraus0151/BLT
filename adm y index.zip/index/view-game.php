<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/index.css">
		<meta charset="UTF-8">
		<!-- JSSOR -->
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
			<link rel="stylesheet" type="text/css" href="css/jssor.css">
		<!-- END JSSOR-->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	</head>
	<body>
		<section>
			<nav>
				<ul>
					<li><a href="index.html"><img src="img/logo.jpg" width="35px"></a></li>
					<li><a href="tienda.html">TIENDA</a></li>
					<li><a href="contato.html">CONTACTO</a></li>
					<li><a href=""><form><input type="text" name="search"></form></a></li>
					<li style="padding:0px 20px;"><a href="carrito.html"><img id="img-nav" src="img/carro.png"></a></li>
					<li><a href="login.html">LOGIN</a></li>
				</ul>
			</nav>
		</section>
		<div>
			<img src="img/wallpaper/capa_doom.jpg" width="100%">
			<img src="img/doom.jpg" style="border: 2px solid rgba(0,0,0,0.0001);border-radius: 15px;margin-top:-250px;margin-left:75px;" width="500px">
			<div style="background-color:#2e3032;width:40%;color:white;right:0;margin-top:-550px;margin-right:120px;padding:20px;position:absolute;">
				<h1>Doom(2016)</h1>
				<p style="color:grey;">13 May 2016</p>
				<p>Ahora incluye los tres paquetes de contenido descargable premium (Unto the Evil-Hell Followed-Bloodfall), mapas, modos y armas, así como todas las actualizaciones de funcionalidades, como el modo Arcade, el modo Foto y la actualización 6.66, la más reciente, que trae más mejoras multijugador.</p>
				<div>
					<div style="float:left;">
						<img src="img/mature.png">
					</div>
					<div style="float:left;position:relative;bottom:10;padding-top:80px;padding-left:10px;">
						<p>Desarrollador:id Software</p>
						<p>Editor:Bethesda Softworks</p>
						<p>Etiquetas: FPS,SANGRIENTO,ACCIÓN(...)</p>
					</div>
				</div>
			</div>
			<div>
				<div style="float:left;background-color:#F8F8F8;height:450px;width:100%;">
					<div style="width:16.6%;float:left;height:100%;">
					</div>
						
					<a href="#">
						<div style="width:14%;background-image:url('img/doom.jpg');float:left;margin-top:50px;height:350px;background-position:center;border-radius:20px;background-size:115%;">
							</div>
					</a>
					<div style="width:3.7%;float:left;height:100%;">
					</div>
							
					<a href="#">
						<div style="width:14%;background-image:url('img/doom.jpg');float:left;margin-top:50px;height:350px;background-position:center;border-radius:20px;background-size:115%;">
						</div>
					</a>
						
					<div style="width:3.7%;float:left;height:100%;">
					</div>
						
					<a href="#">
						<div style="width:14%;background-image:url('img/doom.jpg');float:left;margin-top:50px;height:350px;background-position:center;border-radius:20px;background-size:115%;">
						</div>
					</a>
						
					<div style="width:3.7%;float:left;height:100%;">
					</div>
						
									
					<a href="#">
						<div style="width:14%;background-image:url('img/doom.jpg');float:left;margin-top:50px;height:350px;background-position:center;border-radius:20px;background-size:115%;">
						</div>
					</a>
						
						
					<div style="width:16.6%;float:left;height:10px;">
					</div>
						
				</div>
			</div>
		</div>
		<section id="section-footer">
			<footer>
				<div class="col-lg-3 col-sm-6 footer">
					<div class="title-footer">
						<h3>Menú</h3>
					</div>
					<div class="content-footer">
						<div class="list-style-footer">
							<ul>
								<li>> Home</li>
								<li>> Tienda</li>
								<li>> Carro</li>
								<li>> Login</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 footer">
					<div class="title-footer">
						<h3>Contato</h3>
					</div>
					<div class="content-footer">
						<div class="div-contato-footer">
							<img src="img/icon-endereco.png" width="12px" style="float:left;">
							<p class="p-contato-footer">Direccion:</p>
							<p>Nose que poner ak, nº 1233</p>
						</div>
						<div class="div-contato-footer">
							<img src="img/icon-phone.png" width="12px" style="float:left;">
							<p class="p-contato-footer">Teléfono:</p>
							<p>(123)4567 8976</p>
						</div>
						<div class="div-contato-footer">
							<img src="img/icon-email.png" width="12px" style="float:left;">
							<p class="p-contato-footer">Email:</p>
							<p>
								<a href="">Email</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 footer">
					<div class="title-footer">
						<h3>La empresa</h3>
					</div>
					<div class="content-footer">
						<p>Un breve texto relatando aluna consa que se entiendo como importante o a relatar sobre la empresa o la página de la empresa				ou a página da Santa Casa Livramento.</p>
						<p> Este texto puede tener continuacion del texto anterior o simplismente puede ser feredio a un aspecto de la pagina</p>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 footer">
					<div class="title-footer">
						<h3>Redes Socias</h3>
					</div>
					<div class="content-footer">
						<p>Accese a nuestras redes sociales y este por dentro de todo lo que suecede dentro de nuestra empresa</p>
						<div>
							<img src="img/facebook-icon.png" width="50px">
							<img src="img/twitter-icon.png" width="50px">
							<img src="img/instagram-icon.png" width="50px">
						</div>
					</div>
				</div>
			</footer>
		</section>
	</body>
</html>