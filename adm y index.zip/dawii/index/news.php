<head>
		<link rel="stylesheet" type="text/css" href="css/index.css">
		<meta charset="UTF-8">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	</head>
	<body>
		<section>
			<nav>
				<ul>
					<li><a href="index.php"><img src="img/logo.jpg" width="35px"></a></li>
					<li><a href="tienda.php">TIENDA</a></li>
					<li><a href="contato.php">CONTACTO</a></li>
					<li>
						<form style="position:relative;">
							<input type="search" placeholder="Buscar..." style="border:1px solid white;border-radius:2px;"/>
								<button type="submit" style="position:absolute;top:4px; right:0;z-index:10;border:none;background:transparent;outline:none;">
									<i class="fa fa-search"></i>
								</button>
						</form>
					</li>
					<li style="padding:0px 20px;"><a href="carrito.php"><img id="img-nav" src="img/carro.png"></a></li>
					<li><a href="login.php"style="display:block;float:right;position:absolute;height:30px;right:10px;">LOGIN</a></li>
				</ul>
			</nav>
		<section>
			<div>
				<div id="news-title">
					<h3>Anunciando TeenoVip 2018</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis aliquid atque, nulla?</p>
				</div>
				<img src="img/news/1.jpg" width="100%">
				<img src="img/news/11.jpg" width="70%" style="margin-left:15%;margin-top:-100px;">
			</div>
			<div id="content-news">
				<p>Lorem ipsum dolor sit amet, 
				consectetur adipisicing elit. Vero 
				nulla delectus sit vel magnam, ad vo
				luptatem hic. Maxime ipsam quibusdam
				eius exercitationem iusto, totam poss
				imus dolore magnam voluptatum illum consequuntur.</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. 
				Vero nulla delectus sit vel magnam, ad voluptatem hic. Maxim
				e ipsam quibusdam eius exercitationem iusto, totam possimus 
				dolore magnam voluptatum illum consequuntur.</p><p>

Deserunt cupiditate error repudiandae doloribus est sit id ad repellendus 
voluptates molestiae ratione eaque, iure, odit culpa delectus harum asperio
res ab a aut, molestias possimus! Tempore commodi iste soluta voluptatibus.</p><p>

Quaerat vero velit voluptatem nostrum natus ipsa, eius dicta veritatis iste 
odio maiores harum nesciunt reiciendis, dolore eum animi error quia earum enim
 beatae omnis, laudantium minima ab ut accusamus.</p><p>

Voluptatem, ullam, beatae. Libero ad nemo, id. Quidem facilis, eaque iste 
ducimus dicta quia quaerat quisquam cum ab, velit voluptate at optio vero, 
ostrum enim, a officiis rerum recusandae eum?</p><p>

Laboriosam recusandae vitae aliquid veritatis facilis omnis architecto offi
cia, explicabo deleniti doloribus odio sequi, harum id suscipit ipsa laborum,
 ducimus. Sequi quasi vitae necessitatibus harum ab pariatur eos perspiciatis quo!</p>
			<a href="index.html">Home</a>
			</div>
		</section>
		<section id="section-footer">
			<footer>
				<div class="col-lg-3 col-sm-6 footer">
					<div class="title-footer">
						<h3>Menú</h3>
					</div>
					<div class="content-footer">
						<div class="list-style-footer">
							<ul>
								<li>> Home</li>
								<li>> Tienda</li>
								<li>> Carro</li>
								<li>> Login</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 footer">
					<div class="title-footer">
						<h3>Contato</h3>
					</div>
					<div class="content-footer">
						<div class="div-contato-footer">
							<img src="img/icon-endereco.png" width="12px" style="float:left;">
							<p class="p-contato-footer">Direccion:</p>
							<p class="p2-contato-footer">Nose que poner ak, nº 1233</p>
						</div>
						<div class="div-contato-footer">
							<img src="img/icon-phone.png" width="12px" style="float:left;">
							<p class="p-contato-footer">Teléfono:</p>
							<p class="p2-contato-footer">(123)4567 8976</p>
						</div>
						<div class="div-contato-footer">
							<img src="img/icon-email.png" width="12px" style="float:left;">
							<p class="p-contato-footer">Email:</p>
							<p class="p2-contato-footer">
								<a href="">Email</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 footer">
					<div class="title-footer">
						<h3>La empresa</h3>
					</div>
					<div class="content-footer">
						<p>Un breve texto relatando aluna consa que se entiendo como importante o a relatar sobre la empresa o la página de la empresa				ou a página da Santa Casa Livramento.</p>
						<p> Este texto puede tener continuacion del texto anterior o simplismente puede ser feredio a un aspecto de la pagina</p>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 footer">
					<div class="title-footer">
						<h3>Redes Socias</h3>
					</div>
					<div class="content-footer">
						<p>Accese a nuestras redes sociales y este por dentro de todo lo que suecede dentro de nuestra empresa</p>
						<div>
							<img src="img/facebook-icon.png" width="50px">
							<img src="img/twitter-icon.png" width="50px">
							<img src="img/instagram-icon.png" width="50px">
						</div>
					</div>
				</div>
			</footer>
		</section>
	</body>
</html>