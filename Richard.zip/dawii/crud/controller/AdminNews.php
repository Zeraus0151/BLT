<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AdminNews
 *
 * @author IFSul
 */
class AdminNews extends Admin {

    //put your code here

    public function __construct() {
        parent::__construct();
        $this->model = new NoticiaDAO();
    }

    public function index() {
        $data['listNews'] = $this->model->getListNoticias();
//        echo "<pre>";
//        var_dump($data);
//        echo "</pre>";
        //die;
        $this->view->load("header");
        $this->view->load("nav");
        $this->view->load("noticias", $data);
        $this->view->load("footer");
    }

    public function addNews() {
        $data['msg'] = "";
        if (filter_input(INPUT_POST, 'add')) {
            $titulo = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
            $texto = filter_input(INPUT_POST, 'text', FILTER_SANITIZE_STRING);
            if ($titulo && $texto) {
                if ($this->model->insereNoticia(new Noticia($texto, $titulo))) {
                    $this->view->location('AdminNews');
                } else {
                    $data['msg'] = "Erro ao cadastrar!!";
                }
            } else {
                $data['msg'] = "Preencha todos os campos!";
            }
        }
        $this->view->load('header');
        $this->view->load('nav');
        $this->view->load('add_news', $data);
        $this->view->load('footer');
    }

    public function editNews($id) {
        $data['news'] = $this->model->getNoticiaById($id);
        $data['msg'] = "";

        if (filter_input(INPUT_POST, 'edit')) {
            //ler formulário e atualizar o banco

            $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
            $text = filter_input(INPUT_POST, 'text', FILTER_SANITIZE_STRING);
            $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_STRING);

            if ($title && $text && $id) {
                //atualizar no banco de dados a notícia
                $noticia = new Noticia($text, $title, null, $id);
                if ($this->model->atualizarNoticia($noticia)) {
                    $this->view->location($this->view->getUrl() . "AdminNews");
                    return true;
                } else {
                    $data['msg'] = "Erro ao atualizar notícia!!";
                }
            } else {
                $data['msg'] = "Informe Todos os campos!!";
            }
        } else if (filter_input(INPUT_POST, 'exit')) {
            $this->view->location($this->view->getUrl() . "AdminNews");
//            $this->index();
            return TRUE;
        }

        $this->view->load('header');
        $this->view->load('nav');
        $this->view->load('upd_news', $data);
        $this->view->load('footer');
    }

    public function delNews($id) {
        $data['msg'] = '';
//        echo "Deletar Notícia: $id";
        $data['news'] = $this->model->getNoticiaById($id);
        $this->view->load('header');
        $this->view->load('nav');
        $this->view->load('del_news', $data);
        $this->view->load('footer');
    }

    public function removeNews() {
        $data['msg'] = '';
        if (filter_input(INPUT_POST, 'del')) {
            $id = filter_input(INPUT_POST,'id',FILTER_SANITIZE_STRING);
            if($this->model->removerNoticia($id)){
                $data['msg'] ='Notícia excluída com sucesso!';
            }else{
                $data['msg'] ='Erro ao excluir notícia!';            
            }           
        } elseif (filter_input(INPUT_POST, 'exit')) {
            $this->view->location($this->view->getUrl().'AdminNews/');
        } else {
            $data['msg'] = 'Erro no formulário!';
        }
        $this->view->load('header');
        $this->view->load('nav');
        $this->view->load('remove_news', $data);
        $this->view->load('footer');
        
    }

}
