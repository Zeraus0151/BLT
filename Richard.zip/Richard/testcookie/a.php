<?php

$cookie_name = "JohnDoe";
$nombre = "John Doe";
$apellido = "John Doe";
setcookie($cookie_name,$nombre."/".$apellido, time() + (86400 * 30), "/"); // 86400 = 1 day
?>
<html>
<body>

<?php
if(!isset($_COOKIE[$cookie_name])) {
    echo "Cookie named '" . $cookie_name . "' is not set!";
} else {
	$pieces = explode("/", $_COOKIE[$cookie_name]);
	$nombree = $pieces[0];
	$apellidoo = $pieces[1];
	echo $nombree;
	echo $apellidoo;
    echo "Value is: " . $_COOKIE[$cookie_name];
}
?>

</body>
</html>