<?php
class usuarioDao{
		public function inserir($fecha_ingreso,$tipo,$nombre,$saldo,$estado){
			$conn = mysqli_connect("localhost","root","","dawii");
			$sql = "INSERT INTO usuarios(fecha_ingreso,tipo,nombre,saldo,estado) VALUES('$fecha_ingreso','$tipo','$nombre','$saldo','$estado')";
			mysqli_query( $conn, $sql) or die ('Unable to execute query. '.mysqli_error($conn));
		}
		public function editar($fecha_ingreso,$tipo,$nombre,$saldo,$estado,$idUsuario){
			$conn = mysqli_connect("localhost","root","","dawii");
			$sql = "UPDATE usuarios SET fecha_ingreso = '$fecha_ingreso',tipo = '$tipo',nombre = '$nombre',saldo = '$saldo', estado = '$estado' WHERE idUsuarios = $idUsuarios";
			mysqli_query( $conn, $sql) or die ('Unable to execute query. '.mysqli_error($conn));
		}
		public function mostrar(){
			$conn = mysqli_connect("localhost","root","","dawii");
			$sql = "SELECT * FROM usuarios ";
			$result = mysqli_query( $conn, $sql) or die ('Unable to execute query. '.mysqli_error($conn));
			if ($result->num_rows > 0) {
				//
				while($row = $result->fetch_assoc()) {
					$id = $row["idusuarios"];
					//echo'<a href=editUsers.php?id='.$row["idusuarios"].'>editar</a>';die;
					//no estoy seguro de como agarrar el id del boton,
					//no se si por el value se puede agarrar
					echo"<div style='background-color:white;height:50px;'>
							<div class='col-sm-2' style='float:left;paddin-left:10px;color:grey;padding-top:11px;font-size:20px;'>".$row["fecha_ingreso"]."</div>
							<div class='col-sm-2' style='float:left;paddin-left:10px;color:grey;padding-top:11px;font-size:20px;'>".$row["tipo"]."</div>
							<div class='col-sm-2'style='float:left;paddin-left:10px;color:grey;padding-top:11px;font-size:20px;'>".$row["nombre"]."</div>
							<div class='col-sm-2' style='float:left;paddin-left:10px;color:grey;padding-top:11px;font-size:20px;'>".$row["saldo"]."</div>
							<div class='col-sm-2' style='float:left;paddin-left:10px;color:grey;padding-top:11px;font-size:20px;'>".$row["estado"]."</div>
							<div class='col-sm-1' style='float:left;paddin-left:10px;color:grey;padding-top:11px;font-size:20px;'>1.png</div>
							<div class='col-sm-1' style='float:left;paddin-left:10px;color:grey;padding-top:11px;font-size:20px;'><a href=''>X</a><a href=editarUsers.php?id=".$row["idusuarios"].">Editar</a></div></div>";
				}
			} else {
				echo "0 results";
			}
		}
}
