var c = document.getElementById("canvas");

var width = document.getElementById("canvas").width;
var height = document.getElementById("canvas").height;

var ctxa = c.getContext("2d");


		//orientado a objeto
		/*	
		ctxa.beginPath();
		ctxa.rect(35, 35, 30, 30);
		ctxa.fillStyle = "blue";
		ctxa.fill();
		ctxa.closePath();
		

		ctxa.beginPath();
		ctxa.arc(50,50, 15, 0, 2 * Math.PI);
		ctxa.fillStyle = "black";
		ctxa.fill();
		ctxa.closePath();
		*/
		var key=0;
window.addEventListener('keydown',function(e){
	key = e.which;
	console.log(key);
	//w=87d=68s=83a=65
	//alert(key);
});
window.addEventListener('keyup',function(e){
	key = 0;
	//w=87d=68s=83a=65
	//alert(key);
});
var comida = new Personaje(Math.random()*(width-50),Math.random()*(height-50), 15, 0, 2 * Math.PI,"red");

var fundo = new Enemy(0,0,1280,720, "lightgreen");

var enemigo = new Enemy(Math.random()*(width-50),100,50,50, "green");

var enemigo2 = new Enemy(200,Math.random()*(height-50),50,50, "blue");

var enemigo3 = new Enemy(200,Math.random()*(height-50),50,50, "purple");

var smile = new Smile(220,200, 20, 0, 2 * Math.PI,"yellow");

//var smile = new Smile(220,200,60,0.01*Math.PI,false);
//smile.dibujo(ctxa);

function dibbujo(){
	fundo.desenha(ctxa);
	comida.dibujo(ctxa);
	enemigo.desenha(ctxa);
	enemigo.moveLeft(width,height,2);
	enemigo2.desenha(ctxa);
	enemigo2.moveUp(width,height,2);
	enemigo3.desenha(ctxa);
	enemigo3.moveAngle(width,height,2);
	smile.dibujo(ctxa);
	smile.movimiento(key);
	/*
	smile.x++;smile.y++;
	smile2.x++;smile2.y++;
	smile3.x++;smile3.y++;
	smile4.x++;smile4.y++;
	smile5.x++;smile5.y++;*/
	requestAnimationFrame(dibbujo);
}
dibbujo();


//var i = new Smile(key);
//	i.movimiento(ctxa);

