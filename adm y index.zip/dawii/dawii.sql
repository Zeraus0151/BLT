-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 28-Out-2019 às 14:36
-- Versão do servidor: 10.1.38-MariaDB
-- versão do PHP: 7.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dawii`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `imagenes`
--

CREATE TABLE `imagenes` (
  `idimagenes` int(11) NOT NULL,
  `fecha_creacion` varchar(45) DEFAULT NULL,
  `descripcion` varchar(450) DEFAULT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `noticias_idnoticias` int(11) DEFAULT NULL,
  `usuarios_idusuarios` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `imagenes`
--

INSERT INTO `imagenes` (`idimagenes`, `fecha_creacion`, `descripcion`, `nombre`, `noticias_idnoticias`, `usuarios_idusuarios`) VALUES
(3, '28/0', 'gk', 'ghjk', 1, 1),
(4, 'asdasd', 'sadsad', 'asd', 1, NULL),
(5, '123', 'qwe', 'qwe', NULL, NULL),
(6, 'teste', 'teste', 'teste', 1, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `juegos`
--

CREATE TABLE `juegos` (
  `idjuegos` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `descripcion` varchar(4500) DEFAULT NULL,
  `autor` varchar(45) DEFAULT NULL,
  `distribuidora` varchar(45) DEFAULT NULL,
  `lanzamiento` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `juegos_has_imagenes`
--

CREATE TABLE `juegos_has_imagenes` (
  `juegos_idjuegos` int(11) NOT NULL,
  `imagenes_idimagenes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `noticias`
--

CREATE TABLE `noticias` (
  `idnoticias` int(11) NOT NULL,
  `fecha_creacion` varchar(45) DEFAULT NULL,
  `titulo` varchar(45) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `noticias`
--

INSERT INTO `noticias` (`idnoticias`, `fecha_creacion`, `titulo`, `descripcion`) VALUES
(1, '21/05/20', 'hg', 'g'),
(2, '28/10/2019', 'test2', 'test');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `idusuarios` int(11) NOT NULL,
  `fecha_ingreso` varchar(45) DEFAULT NULL,
  `tipo` varchar(45) DEFAULT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `saldo` varchar(45) DEFAULT NULL,
  `estado` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`idusuarios`, `fecha_ingreso`, `tipo`, `nombre`, `saldo`, `estado`) VALUES
(1, 'sadasd', 'Administrador', 'dsfagf', 'fasd', 'sadf'),
(2, '123123', '1231', '23123', '123', '123123'),
(3, '28/02/52', 'Cliente', 'Richard SUarez', '231', 'Activo');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `imagenes`
--
ALTER TABLE `imagenes`
  ADD PRIMARY KEY (`idimagenes`),
  ADD KEY `fk_imagenes_noticias_idx` (`noticias_idnoticias`),
  ADD KEY `fk_imagenes_usuarios1_idx` (`usuarios_idusuarios`);

--
-- Indexes for table `juegos`
--
ALTER TABLE `juegos`
  ADD PRIMARY KEY (`idjuegos`);

--
-- Indexes for table `juegos_has_imagenes`
--
ALTER TABLE `juegos_has_imagenes`
  ADD PRIMARY KEY (`juegos_idjuegos`,`imagenes_idimagenes`),
  ADD KEY `fk_juegos_has_imagenes_imagenes1_idx` (`imagenes_idimagenes`),
  ADD KEY `fk_juegos_has_imagenes_juegos1_idx` (`juegos_idjuegos`);

--
-- Indexes for table `noticias`
--
ALTER TABLE `noticias`
  ADD PRIMARY KEY (`idnoticias`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idusuarios`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `imagenes`
--
ALTER TABLE `imagenes`
  MODIFY `idimagenes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `juegos`
--
ALTER TABLE `juegos`
  MODIFY `idjuegos` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `noticias`
--
ALTER TABLE `noticias`
  MODIFY `idnoticias` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idusuarios` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `imagenes`
--
ALTER TABLE `imagenes`
  ADD CONSTRAINT `fk_imagenes_noticias` FOREIGN KEY (`noticias_idnoticias`) REFERENCES `noticias` (`idnoticias`),
  ADD CONSTRAINT `fk_imagenes_usuarios1` FOREIGN KEY (`usuarios_idusuarios`) REFERENCES `usuarios` (`idusuarios`);

--
-- Limitadores para a tabela `juegos_has_imagenes`
--
ALTER TABLE `juegos_has_imagenes`
  ADD CONSTRAINT `fk_juegos_has_imagenes_imagenes1` FOREIGN KEY (`imagenes_idimagenes`) REFERENCES `imagenes` (`idimagenes`),
  ADD CONSTRAINT `fk_juegos_has_imagenes_juegos1` FOREIGN KEY (`juegos_idjuegos`) REFERENCES `juegos` (`idjuegos`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
