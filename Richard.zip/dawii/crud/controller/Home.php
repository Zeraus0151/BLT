<?php
class Home extends Controller{

    //private $texto;

    public function __construct() {
        parent::__construct();
        //$this->texto = "Olá Mundo!!";        
    }

    public function index(){
        //echo $this->texto;
        
        $data['listNews'] = (new NoticiaDAO())->getListNoticiasImagens();

        $this->view->load('header');
        $this->view->load('index',$data);
        $this->view->load('footer');
    }

    public function imprimir($texto = null) {
        $this->texto = ($texto) ? $texto : $this->texto;
        echo $this->texto;
    }

}
